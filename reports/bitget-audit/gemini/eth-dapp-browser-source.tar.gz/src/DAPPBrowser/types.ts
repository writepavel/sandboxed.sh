export type ChainConfig = {
  currency: string;
  nodeURL: string;
  chainID: number;
};
